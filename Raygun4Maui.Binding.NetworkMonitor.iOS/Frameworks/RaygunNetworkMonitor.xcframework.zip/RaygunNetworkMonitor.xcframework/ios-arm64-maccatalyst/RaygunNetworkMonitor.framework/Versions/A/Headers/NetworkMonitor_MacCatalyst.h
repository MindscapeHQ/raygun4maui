//
//  NetworkMonitor_MacCatalyst.h
//  NetworkMonitor MacCatalyst
//
//  Created by dev on 15/01/2025.
//

#import <Foundation/Foundation.h>

//! Project version number for NetworkMonitor_MacCatalyst.
FOUNDATION_EXPORT double NetworkMonitor_MacCatalystVersionNumber;

//! Project version string for NetworkMonitor_MacCatalyst.
FOUNDATION_EXPORT const unsigned char NetworkMonitor_MacCatalystVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetworkMonitor_MacCatalyst/PublicHeader.h>


