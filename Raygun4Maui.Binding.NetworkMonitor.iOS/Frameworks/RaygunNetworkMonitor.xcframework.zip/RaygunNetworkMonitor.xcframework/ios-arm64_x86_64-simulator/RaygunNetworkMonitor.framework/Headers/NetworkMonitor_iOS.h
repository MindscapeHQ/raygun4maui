//
//  NetworkMonitor_iOS.h
//  NetworkMonitor iOS
//
//  Created by Mitchell Duncan on 10/06/19.
//

#import <UIKit/UIKit.h>

//! Project version number for NetworkMonitor_iOS.
FOUNDATION_EXPORT double NetworkMonitor_iOSVersionNumber;

//! Project version string for NetworkMonitor_iOS.
FOUNDATION_EXPORT const unsigned char NetworkMonitor_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetworkMonitor_iOS/PublicHeader.h>

#import "RaygunDefines.h"
#import "RaygunNetworkMonitor.h"
